package com.ams.service;

import java.util.ArrayList;

import com.ams.bean.Request;
import com.ams.bean.UserMaster;

public interface IAssetService {

	int storeRaisedRequest(Request req);

	UserMaster login(UserMaster user);

}
