package com.ams.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ams.bean.Request;
import com.ams.bean.UserMaster;
import com.ams.service.IAssetService;

@Controller
public class AssetController {
	
	@Autowired
	private IAssetService assetserv;

	@RequestMapping("home")
	public String getHome()
	{
		return "home";
	}
	
	@RequestMapping("getlogin")
	public String getLoginPage(Model m)
	{
		UserMaster userMaster=new UserMaster();
		m.addAttribute("loginObj",userMaster);
		return "login";
	}
	
	@RequestMapping(value="checklogin",method=RequestMethod.POST)
	public String validateLogin(Model m,@ModelAttribute("loginObj") UserMaster user)
	{
		UserMaster checkUser=null;
		String target=null;
		checkUser=assetserv.login(user);
		System.out.println("returned with value");
		System.out.println(checkUser);
		
		System.out.println(checkUser.getUserType());
		
		if(checkUser.getUserType()==null)
		{
			m.addAttribute("InvalidLogin","Login Cedentials are not valid");
			target="login";
		}
		else if("Manager".equals(checkUser.getUserType()))
		{
			target="managerDashboard";
		}
		else if("Admin".equals(checkUser.getUserType()))
		{
			target="adminDashboard";
		}
		else{
			m.addAttribute("InvalidLogin","Login Cedentials are not valid");
			target="login";
		}
		return target;
	
	}

	@RequestMapping("managerDashboard")
	public String getManagerDashboard()
	{
		return "managerDashboard";
	}
	
	@RequestMapping(value="raiseRequest")
	public String getRequestPage(Model m)
	{
		System.out.println("in raise Request");
		Request req=new Request();
		m.addAttribute("requestObj",req);
		return "raiseRequest";
	}
	
	@RequestMapping(value="raise",method=RequestMethod.POST)
	public String viewStatusPage(Model m,@ModelAttribute("requestObj") Request req)
	{
		System.out.println("In Store method");
		String target=null;
		int reqid=assetserv.storeRaisedRequest(req);
		if(reqid>0)
		{
			System.out.println("in IF");
			m.addAttribute("msg","Request Stored Successfully");
			m.addAttribute("requestId", reqid);
			target="success";
		}
		else{
			target="raiseRequest";
		}
		return target;
}
	
	@RequestMapping("viewStatus")
	public String getStatusPage()
	{
		return "viewStatus";
	}

}
