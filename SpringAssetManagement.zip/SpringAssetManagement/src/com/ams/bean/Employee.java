package com.ams.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {

	@Id
	@GeneratedValue
	@Column(name="Empno")
	private int empID;
	@Column(name="Ename")
	private String empName;
	@Column(name="job")
	private String job;
	@Column(name="mgr")
	private int mgrId;
	@Column(name="hiredate")
	private Date hireDate;
	@Column(name="Dept_ID")
	private int departmentId;
	
	public Employee() {
		
	}

	public Employee(int empID, String empName, String job, int mgrId,
			Date hireDate, int departmentId) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.job = job;
		this.mgrId = mgrId;
		this.hireDate = hireDate;
		this.departmentId = departmentId;
	}

	public Employee(String empName, String job, int mgrId, Date hireDate,
			int departmentId) {
		super();
		this.empName = empName;
		this.job = job;
		this.mgrId = mgrId;
		this.hireDate = hireDate;
		this.departmentId = departmentId;
	}

	public int getEmpID() {
		return empID;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgrId() {
		return mgrId;
	}

	public void setMgrId(int mgrId) {
		this.mgrId = mgrId;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + ", job="
				+ job + ", mgrId=" + mgrId + ", hireDate=" + hireDate
				+ ", departmentId=" + departmentId + "]";
	}
	
}
