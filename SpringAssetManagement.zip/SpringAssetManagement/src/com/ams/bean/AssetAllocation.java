package com.ams.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="assetallocation")
public class AssetAllocation {

		@Id
		@GeneratedValue
		@Column(name="AllocationId")
		private int allocationId;
		@Column(name="Allocation_date")
		private String allocationDate;
		@Column(name="Release_date")
		private String releaseDate;
		@Column(name="AssetId")
		private int assetId;
		@Column(name="Empno")
		private int empId;
		
		public int getAllocationId() {
			return allocationId;
		}

		public void setAllocationId(int allocationId) {
			this.allocationId = allocationId;
		}

		public String getAllocationDate() {
			return allocationDate;
		}

		public void setAllocationDate(String allocationDate) {
			this.allocationDate = allocationDate;
		}

		public String getReleaseDate() {
			return releaseDate;
		}

		public void setReleaseDate(String releaseDate) {
			this.releaseDate = releaseDate;
		}

		public int getAssetId() {
			return assetId;
		}

		public void setAssetId(int assetId) {
			this.assetId = assetId;
		}

		public int getEmpId() {
			return empId;
		}

		public void setEmpId(int empId) {
			this.empId = empId;
		}

		public AssetAllocation() {
			
		}

		public AssetAllocation(int allocationId, String allocationDate,
				String releaseDate, int assetId, int empId) {
			super();
			this.allocationId = allocationId;
			this.allocationDate = allocationDate;
			this.releaseDate = releaseDate;
			this.assetId = assetId;
			this.empId = empId;
		}

		public AssetAllocation(String allocationDate, String releaseDate,
				int assetId, int empId) {
			super();
			this.allocationDate = allocationDate;
			this.releaseDate = releaseDate;
			this.assetId = assetId;
			this.empId = empId;
		}

		@Override
		public String toString() {
			return "AssetAllocation [allocationId=" + allocationId
					+ ", allocationDate=" + allocationDate + ", releaseDate="
					+ releaseDate + ", assetId=" + assetId + ", empId=" + empId
					+ "]";
		}
		
}
