package com.ams.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ams.bean.Request;
import com.ams.bean.UserMaster;

@Repository
@Transactional
public class AssetDaoImpl implements IAssetDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int storeRaisedRequest(Request req) {
		System.out.println("Adding ....");
		entityManager.persist(req);
		System.out.println("Added");
		System.out.println(req.getRequestId());
		return req.getRequestId();
	}

	@Override
	public UserMaster login(UserMaster user) {
		Query qry=entityManager.createQuery("select u from UserMaster u where u.userName=:usr and u.password=:pass");
		System.out.println("after query");
		qry.setParameter("usr", user.getUserName());
		qry.setParameter("pass", user.getPassword());
		System.out.println("adding in list");
		List list=qry.getResultList();
		System.out.println("added in list");

		if(list.isEmpty())
		{
			user.setUserType("Manager");
		}
		else
		{
			user.setUserType("Admin");
		}
		return user;
	}

}
