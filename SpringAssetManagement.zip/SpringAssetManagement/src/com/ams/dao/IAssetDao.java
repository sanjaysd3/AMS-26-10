package com.ams.dao;

import java.util.ArrayList;

import com.ams.bean.Request;
import com.ams.bean.UserMaster;

public interface IAssetDao {

	int storeRaisedRequest(Request req);

	UserMaster login(UserMaster user);

}
